/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package sominie.samsara;

public class Samsara {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
